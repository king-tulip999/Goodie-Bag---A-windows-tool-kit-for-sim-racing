# Track maps: third-party sources, licences and attribution

The iRacing Overlay's **Track map** widget draws from a library bundled inside Goodie Bag (`src/GoodieBag/Assets/TrackMaps.zip`,
built by `devtools\track-maps.cmd`). This file lists where its geometry comes from and under which terms. It is packed into
the library itself, so it ships with the app.

| Source | What's used | Licence | Configurations in the library |
| --- | --- | --- | --- |
| [meowmachine/racing-track-maps-vector](https://github.com/meowmachine/racing-track-maps-vector), folder `from-iracing/` | The map layers of each iRacing track configuration (active line, pit road, start / finish with direction, turn numbers), converted to Goodie Bag's own simplified SVG; plus the metadata JSON (track IDs, folder names, categories) used at build time for configuration identity and the coverage report | **None stated.** The repository has no licence file. Its README says the SVGs were collected from iRacing's member website and asset server, so the drawings are iRacing's own artwork. | see `coverage.md` (source `IracingSvg`) |
| [SIMRacingApps/SIMRacingAppsServer](https://github.com/SIMRacingApps/SIMRacingAppsServer), folder `src/com/SIMRacingApps/Tracks/` | GPX route files (track centreline and pit lane, latitude / longitude) for configurations whose iRacing layers can't be turned into a usable map, and for older configurations no longer listed | **Apache License 2.0**, Copyright (C) 2015 - 2024 Jeffrey Gilliam. Licence and NOTICE text below and in the library (`LICENSE-GPX.txt`, `NOTICE-GPX.txt`) | see `coverage.md` (source `Gpx`) |
| The driver's own laps | Maps Goodie Bag draws from the user's clean laps for configurations without bundled geometry, kept on their PC only (`%APPDATA%\GoodieBag\iRacing\TrackMaps\Learned`) | The user's own data; never bundled or uploaded | – |

## Important: the iRacing-derived maps

Bundling the iRacing-derived layers was a deliberate decision by the project owner, made knowing that:

- the source repository grants **no licence**, so by default no redistribution rights are given; and
- the underlying drawings are iRacing's (iRacing.com Motorsport Simulations, LLC), published on their member website.

Before distributing Goodie Bag publicly, confirm permission with the rights holders, or rebuild the library without them:
`devtools\track-maps.cmd` with an empty folder as the first argument builds from the Apache-licensed GPX routes only (about 200
configurations; the rest are then learned from driving).

None of the other projects' code is used: the importer, the SVG reader, the centreline and the widget are Goodie Bag's own.

## Apache License 2.0 (GPX routes)

```
Copyright (C) 2015 - 2024 Jeffrey Gilliam

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```

Changes made to the GPX data: routes are projected from latitude / longitude to a flat drawing, scaled, resampled to evenly
spaced points and written as Goodie Bag track map SVGs.
